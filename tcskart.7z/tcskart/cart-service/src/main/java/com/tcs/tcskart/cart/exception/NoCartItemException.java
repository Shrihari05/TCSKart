package com.tcs.tcskart.cart.exception;

public class NoCartItemException extends Exception{

}
