package com.tcs.tcskart.cart.exception;

public class InvalidProductException extends Exception {

}
