package com.tcs.tcskart.cart.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.tcs.tcskart.cart.exception.InvalidProductException;
import com.tcs.tcskart.cart.exception.NoCartItemException;
import com.tcs.tcskart.cart.model.Cart;
import com.tcs.tcskart.cart.model.CartItem;

public interface CartServiceInterface {
	
	public Cart getCartByUserId(Long userId) throws NoCartItemException;
	
	public Boolean addProductToUserCart(Long userId, Long productId, Integer quantity) throws InvalidProductException, JsonMappingException, JsonProcessingException;
	
	public Boolean deleteCartItemByProductIdWithQuantity(Long userId, Long productId, Integer quantity) throws Exception;
	
	public Boolean deleteCartItemByProductIdWithoutQuantity(Long userId, Long productId) throws Exception;
	
	public Boolean deleteAllCartItemOfUserId(Long userId) throws Exception;
	
}
