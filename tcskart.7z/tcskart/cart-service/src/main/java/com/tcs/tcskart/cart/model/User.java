package com.tcs.tcskart.cart.model; // Package set to 'bean'

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// This User model in the Product Service is a simple DTO/bean
// to hold information extracted from the JWT. It does NOT need to be a JPA @Entity here.
@Data // Generates getters, setters, toString, equals, hashCode
@NoArgsConstructor // Lombok annotation for no-arg constructor
@AllArgsConstructor // Lombok annotation for all-arg constructor (useful for testing)
public class User {

    private Long id;
    private String email;
    private Role role; // Use the Product Service's Role enum from the 'bean' package

    // No password or other sensitive info needed here, as it's from a validated JWT.
}