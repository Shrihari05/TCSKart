package com.tcs.tcskart.cart.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.tcs.tcskart.cart.dto.Product;
import com.tcs.tcskart.cart.dto.ProductImages;
import com.tcs.tcskart.cart.exception.InvalidProductException;
import com.tcs.tcskart.cart.exception.InvalidQuantityException;
import com.tcs.tcskart.cart.exception.NoCartItemException;
import com.tcs.tcskart.cart.exception.ProductNotPresentInCartException;
import com.tcs.tcskart.cart.model.Cart;
import com.tcs.tcskart.cart.model.CartItem;
import com.tcs.tcskart.cart.repository.CartItemRepository;
import com.tcs.tcskart.cart.repository.CartRepository;

@Service
public class CartService implements CartServiceInterface {

	private final CartItemRepository cartItemRepository;
	private final CartRepository cartRepository;
	
	//constructor
	public CartService(CartItemRepository cartItemRepository, CartRepository cartRepository) {
		this.cartItemRepository = cartItemRepository;
		this.cartRepository = cartRepository;
	}

	
	//return all Cart of User by User Id
	@Override
	public Cart getCartByUserId(Long userId) throws NoCartItemException {
		Optional<Cart> cartExist = cartRepository.findByUserId(userId);
		if(cartExist.isEmpty())
			throw new NoCartItemException();
		return cartExist.get();
	}

	//add product to cart item then add to cart 
	@Override
	public Boolean addProductToUserCart(Long userId, Long productId, Integer quantity) throws InvalidProductException, JsonMappingException, JsonProcessingException {

		//checking whether cart for this user had been created or not
		Optional<Cart> cartExist = cartRepository.findByUserId(userId);
		Cart cart;
		
		if(cartExist.isPresent())
			cart = cartExist.get(); //if exists, fetching the same cart
		else {
			cart = new Cart(userId, 0.0);
			cart = cartRepository.save(cart); // if not exists, creating new cart
		}
		
		//get product info from product service by productId
		Product product = getProductByProductId(productId);
		System.out.println(product);
		System.out.println();
		System.out.println(product.toString());
		
		//product not exists in product service
		if(product==null)
			throw new InvalidProductException();
		
		
		
		Optional<CartItem> cartItemExist = cartItemRepository.findByProductIdAndUserId(productId, userId);
		CartItem cartItem;
		
		//if product is already in cart
		if(cartItemExist.isPresent()) {
			cartItem = cartItemExist.get();
			cartItem.setProductName(product.getName());
			cartItem.setImgUrl(product.getImgurl().get(0).getUrl());
			cartItem.setPrice(cartItem.getPrice() + (quantity*product.getPrice() ));
			cartItem.setQuantity(cartItem.getQuantity() + quantity);
			cartItem.setAddedAt(LocalDateTime.now());
		}
		
		//if product is not in cart then creating cart item
		else {
			cartItem = new CartItem(cart.getCartId(), userId, productId, product.getName(), product.getImgurl().get(0).getUrl(), quantity, product.getPrice()*quantity);
		}
		
		//updating or adding cart item in database
		cart.getCartItems().add(cartItem);
		cart.updateTotalPrice();
		if(cartItemRepository.save(cartItem)==null)
			return false;
		if(cartRepository.save(cart)==null)
			return false;
		return true;
	} 

	//delete product from cart by quantity
	@Override
	public Boolean deleteCartItemByProductIdWithQuantity(Long userId, Long productId, Integer quantity) throws Exception {
		
		quantity *= -1;
		//if quantity is negative
		if(quantity<=0) 
			throw new InvalidQuantityException();
		
		//checking whether cart of this user exists or not
		Optional<Cart> cartExist = cartRepository.findByUserId(userId);
		if(cartExist.isEmpty())
			throw new NoCartItemException();
		Cart cart = cartExist.get();
		
		//checking whether this product is present in this user cart or not
		Optional<CartItem> cartItemExist = cartItemRepository.findByProductIdAndUserId(productId, userId);
		if(cartItemExist.isEmpty())
			throw new ProductNotPresentInCartException();
		CartItem cartItem = cartItemExist.get();
		
		//product quantity is same as quantity to remove
		if(cartItem.getQuantity()==quantity) {
			cartItemRepository.delete(cartItemRepository.findByProductId(productId)); //remove from CartItem table
			cart.getCartItems().remove(cartItem);
			cart.updateTotalPrice();
			
		}
		
		//product quantity is more than quantity to remove
		else if(cartItem.getQuantity()>quantity ) {
			cart.getCartItems().remove(cartItem);
			cartItem.setPrice(cartItem.getPrice() - (cartItem.getPrice()/cartItem.getQuantity()) * quantity);
			cartItem.setQuantity(cartItem.getQuantity() - quantity);
			if(cartItemRepository.save(cartItem)==null)
				return false;
			cart.getCartItems().add(cartItem);
			cart.updateTotalPrice();
		}
		
		//product quantity is less than quantity to remove
		else {
			throw new InvalidQuantityException();
		}
		
		//if cart is empty then delete the cart
		if(cartItemRepository.findAllByUserId(userId).isEmpty()) {
			cartRepository.delete(cartRepository.findByUserId(userId).get());
			return true;
		}
			
		//updating cart table
		if(cartRepository.save(cart)==null) 
			return false;
		
		return true;
	}

	//delete product completely from cart 
	@Override
	public Boolean deleteCartItemByProductIdWithoutQuantity(Long userId, Long productId) throws Exception {
		
		//checking whether this product is present in this user cart or not
		Optional<CartItem> cartItemExist = cartItemRepository.findByProductIdAndUserId(productId, userId);
		if(cartItemExist.isEmpty())
			throw new ProductNotPresentInCartException();
		CartItem cartItem = cartItemExist.get();
		
		return deleteCartItemByProductIdWithQuantity(userId, productId, cartItem.getQuantity());
	}
	
	//clear all items from cart and also cart by userId 
	@Override
	public Boolean deleteAllCartItemOfUserId(Long userId) throws Exception {
		//checking cart is present or not
		if(cartRepository.findByUserId(userId).isEmpty())
			throw new NoCartItemException();
		cartItemRepository.deleteAll(cartItemRepository.findAllByUserId(userId));
		cartRepository.delete(cartRepository.findByUserId(userId).get());
		return true;
	}
	
	
	
	public Product getProductByProductId(Long productId) {
		
		RestTemplate restTemplate = new RestTemplate();
		String productServiceUrl = "http://localhost:8082/products/" + productId;

        // Send GET request and fetch response as a map
        ResponseEntity<Map<String, Object>> responseEntity = restTemplate.exchange(
        		productServiceUrl,
            HttpMethod.GET,
            null,
            new ParameterizedTypeReference<Map<String, Object>>() {}
        );

        // Extract the response body
        Map<String, Object> responseBody = responseEntity.getBody();
        boolean success = (boolean) responseBody.get("success");

        System.out.println(responseBody.get("data"));

        
        // If the product is found, process the data
        if (success) {
            Map<String, Object> data = (Map<String, Object>) responseBody.get("data");

            // Manually extract each field from the 'data' map
            Long id = ((Number) data.get("id")).longValue();
            String name = (String) data.get("name");
            String description = (String) data.get("description");
            Double price = (Double) data.get("price");
            String category = (String) data.get("category");
            Integer stockQuantity = ((Number) data.get("stockQuantity")).intValue();
            String createdAtString = (String) data.get("createdAt");

            // Parse 'createdAt' manually to LocalDateTime
            LocalDateTime createdAt = LocalDateTime.parse(createdAtString);  // Assuming ISO 8601 format
            
            // Manually extract the 'imgUrl' field (List of ProductImages)
            List<Map<String, Object>> imgurlData = (List<Map<String, Object>>) data.get("imgurl");
            List<ProductImages> imgUrl = new ArrayList<>();
            for (Map<String, Object> imgData : imgurlData) {
                Long imgId = ((Number) imgData.get("id")).longValue();
                String imgurlStr = (String) imgData.get("url");
                imgUrl.add(new ProductImages(imgId, imgurlStr));
            }

            // Create the Product object and set its properties
            Product product = new Product();
            product.setId(id);
            product.setName(name);
            product.setDescription(description);
            product.setPrice(price);
            product.setCategory(category);
            product.setStockQuantity(stockQuantity);
            product.setCreatedAt(createdAt);
            product.setImgurl(imgUrl);

            return product;
        } else {
            return null;
        }
    }
	
	
	
//	// Method to get Product by ID
//    public Product getProductByProductId(Long productId) {
//		String productServiceUrl = "http://localhost:8082/products/" + productId;
//
//        RestTemplate restTemplate = new RestTemplate();
//        ObjectMapper objectMapper = new ObjectMapper();
//        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//        objectMapper.registerModule(new JavaTimeModule()); 
//
//        // Use ParameterizedTypeReference to specify the response type
//        ResponseEntity<Map<String, Object>> responseEntity = restTemplate.exchange(
//            productServiceUrl,
//            HttpMethod.GET,
//            null,
//            new ParameterizedTypeReference<Map<String, Object>>() {}
//        );
//
//        Map<String, Object> responseBody = responseEntity.getBody();
//        boolean success = (boolean) responseBody.get("success");
//
//        if (success) {
////            Map<String, Object> productData = (Map<String, Object>) responseBody.get("data");
//
//            Object dataObject = responseBody.get("data");
//            Product product = objectMapper.convertValue(dataObject, Product.class);
//            return product;
//        } else {
//            return null;
//        }
//    }
	
}
