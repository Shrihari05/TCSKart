package com.tcs.tcskart.cart.exception;

public class InvalidQuantityException extends Exception {

}
