package com.tcs.tcskart.cart.exception;

public class ProductNotPresentInCartException extends Exception {

}
