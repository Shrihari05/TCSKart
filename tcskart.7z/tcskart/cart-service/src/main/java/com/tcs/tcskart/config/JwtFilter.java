package com.tcs.tcskart.config;



import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.tcs.tcskart.cart.service.JWTService;
import com.tcs.tcskart.cart.service.JwtBasedUserDetailsService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;

import java.io.IOException;

@Component
public class JwtFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtFilter.class);

    @Autowired
    private JWTService jwtService;

    @Autowired
    private JwtBasedUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String requestTokenHeader = request.getHeader("Authorization");

        String username = null;
        String jwtToken = null;

        // Check if token exists and starts with "Bearer "
        if (requestTokenHeader != null && requestTokenHeader.startsWith("Bearer ")) {
            jwtToken = requestTokenHeader.substring(7); // Extract token after "Bearer "
            try {
                // Extract username (email) from token
                username = jwtService.extractUsername(jwtToken);
                logger.info("Product Service - Extracted username from JWT: {}", username);
            } catch (IllegalArgumentException e) {
                logger.error("Product Service - Unable to get JWT Token: {}", e.getMessage());
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Unable to get JWT Token");
                return;
            } catch (ExpiredJwtException e) {
            	System.out.println("gjjg");
                logger.error("Product Service - JWT Token has expired for user {}: {}", username, e.getMessage());
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "JWT Token has expired");
                return;
            } catch (MalformedJwtException e) {
                logger.error("Product Service - Invalid JWT Token format: {}", e.getMessage());
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid JWT Token format");
                return;
            } catch (Exception e) {
                logger.error("Product Service - An unexpected error occurred during JWT processing: {}", e.getMessage(), e);
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred");
                return;
            }
        } else {
            logger.warn("Product Service - JWT Token does not begin with Bearer String or is null for request: {}", request.getRequestURI());
            // Allow the request to proceed if no token is present,
            // Spring Security will then handle authorization for protected resources.
            // If the endpoint is protected, it will result in 401/403 later.
        }

        // Validate token only if username is extracted and no authentication is currently set
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            String role = jwtService.extractClaim(jwtToken, claims -> claims.get("role", String.class));
            Long userId = jwtService.extractClaim(jwtToken, claims -> claims.get("userId", Long.class));

            // Build UserDetails using data from JWT
            UserDetails userDetails = this.userDetailsService.buildUserDetailsFromClaims(username, role, userId);

            // If token is valid, configure Spring Security to set authentication
            if (jwtService.validateToken(jwtToken, userDetails)) {
                UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                        userDetails, null, userDetails.getAuthorities());
                authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
                logger.info("Product Service - Authentication successful for user: {}. Authorities: {}", username, userDetails.getAuthorities());
            } else {
                logger.warn("Product Service - JWT Token validation failed for user: {}", username);
                // No explicit error response here, let Spring Security handle it if the resource is protected
            }
        }

        filterChain.doFilter(request, response);
    }
}