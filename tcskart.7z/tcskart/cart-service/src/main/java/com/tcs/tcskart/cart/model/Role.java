package com.tcs.tcskart.cart.model; // Package set to 'bean'

public enum Role {
    ADMIN, CUSTOMER
}