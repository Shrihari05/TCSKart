package com.example.user_service.configuration;

import com.example.user_service.service.JWTService;
import com.example.user_service.service.MyUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtFilter.class);

    @Autowired
    private JWTService jwtService;

    @Autowired
    private MyUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        // --- START DEBUGGING PRINTS ---
        System.out.println("\n--- Entering JwtFilter ---");
        System.out.println("Request URI: " + request.getRequestURI());
        System.out.println("Request Method: " + request.getMethod());
        System.out.println("Authorization Header: " + request.getHeader("Authorization"));
        boolean shouldFilterResult = shouldNotFilter(request);
        System.out.println("shouldNotFilter returned: " + shouldFilterResult);
        // --- END DEBUGGING PRINTS ---

        if (shouldFilterResult) {
            System.out.println("Bypassing JwtFilter for URI: " + request.getRequestURI());
            filterChain.doFilter(request, response);
            System.out.println("--- Exiting JwtFilter (bypassed) ---\n");
            return;
        }

        String authHeader = request.getHeader("Authorization");
        String token = null;
        String userEmail = null;
        String userRole = null;
        Long userId = null;

        // Extract token and validate it
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            try {
                userEmail = jwtService.extractUserEmail(token);
                userRole = jwtService.extractRole(token);
                userId = jwtService.extractUserId(token);

                logger.debug("JWT Extracted - Email: {}, Role: {}, UserId: {}", userEmail, userRole, userId);

            } catch (ExpiredJwtException e) {
                logger.warn("JWT Expired: {}", e.getMessage());
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 401 Unauthorized
                response.getWriter().write("Authorization token has expired.");
                System.out.println("--- Exiting JwtFilter (JWT Expired) ---\n");
                return;
            } catch (SignatureException | MalformedJwtException e) {
                logger.warn("JWT Invalid Signature or Malformed: {}", e.getMessage());
                response.setStatus(HttpServletResponse.SC_FORBIDDEN); // 403 Forbidden
                response.getWriter().write("Invalid or malformed authorization token.");
                System.out.println("--- Exiting JwtFilter (JWT Invalid/Malformed) ---\n");
                return;
            } catch (Exception e) {
                logger.error("Error processing JWT: {}", e.getMessage(), e);
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400 Bad Request
                response.getWriter().write("Error occurred while processing authorization token: " + e.getMessage());
                System.out.println("--- Exiting JwtFilter (JWT Processing Error) ---\n");
                return;
            }
        } else {
            logger.debug("No Authorization header or not a Bearer token for URI: {}", request.getRequestURI());
        }

        // Validate token and set Spring Security context
        if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            UserDetails userDetails = userDetailsService.loadUserByUsername(userEmail);
            if (jwtService.validateToken(token, userDetails)) {
                SimpleGrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + userRole);
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null, Collections.singletonList(authority));
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authToken);
                logger.debug("SecurityContextHolder updated with authentication for user: {}", userEmail);
            } else {
                logger.warn("JWT validation failed for user: {}", userEmail);
            }
        }

        // Continue with the filter chain
        filterChain.doFilter(request, response);
        System.out.println("--- Exiting JwtFilter (continuing chain) ---\n");
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        // Skip JWT filter for public routes like /login, /register, /hello
        // Note: request.getRequestURI() gives the full path starting from the context root, e.g., "/api/auth/login"
        return request.getRequestURI().equals("/api/auth/login") ||
               request.getRequestURI().equals("/api/auth/register") ||
               request.getRequestURI().equals("/api/auth/hello");
    }
}