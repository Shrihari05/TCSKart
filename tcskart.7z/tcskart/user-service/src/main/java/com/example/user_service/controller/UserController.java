package com.example.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping; // Make sure this is imported
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user_service.errorhandling.UserAlreadyExistsException;
import com.example.user_service.model.LoginRequest;
import com.example.user_service.model.User;
import com.example.user_service.service.UserService;

import org.slf4j.Logger; // Import Logger
import org.slf4j.LoggerFactory; // Import LoggerFactory

@CrossOrigin
@RestController
@RequestMapping("/api/auth")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class); // <--- Add logger

    private final UserService userService;
  
    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/hello")
    public String helloWorld() {
        logger.info("Received GET request for /api/auth/hello"); // <--- Add logging
        return "Hello World! This is a public endpoint.";
    }

    @GetMapping("/admin")
    public String adminOnlyEndpoint() {
        logger.info("Received GET request for /api/auth/admin (Admin endpoint)"); // <--- Add logging
        return "Welcome, Admin! You have special privileges.";
    }

    @GetMapping("/customer")
    public String customerOnlyEndpoint() {
        logger.info("Received GET request for /api/auth/customer (Customer endpoint)"); // <--- Add logging
        return "Welcome, Customer! You can view your specific data.";
    }

    @PostMapping("/login") // <--- CONFIRMED: Changed to @PostMapping
    public ResponseEntity<String> userLogin(@RequestBody LoginRequest loginRequest) {
        logger.info("Received POST request for /api/auth/login for email: {}", loginRequest.getEmail()); // <--- Add logging
        try {
            String jwtToken = userService.authenticateAndGetJwtToken(loginRequest);
            logger.info("Login successful for email: {}", loginRequest.getEmail()); // <--- Add logging
            return ResponseEntity.ok(jwtToken);
        } catch (BadCredentialsException e) {
            logger.warn("Login failed: Invalid email or password for email: {}", loginRequest.getEmail()); // <--- Add logging
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        } catch (Exception e) {
            logger.error("Login failed for email: {} with unexpected error: {}", loginRequest.getEmail(), e.getMessage(), e); // <--- Add logging with stack trace
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Login failed: " + e.getMessage());
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> addUser(@RequestBody User user) {
        logger.info("Received POST request for /api/auth/register for email: {}", user.getEmail()); // <--- Add logging
        try {
            User registeredUser = userService.addUser(user);
            logger.info("User registered successfully: {}", registeredUser.getEmail()); // <--- Add logging
            return ResponseEntity.status(HttpStatus.CREATED)
                                 .body("User registered successfully: " + registeredUser.getEmail() + " with role: " + registeredUser.getRole());
        } catch (UserAlreadyExistsException e) {
            logger.warn("Registration failed: User already exists for email: {}", user.getEmail()); // <--- Add logging
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            logger.warn("Registration failed: Invalid role for email: {}", user.getEmail()); // <--- Add logging
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            logger.error("Registration failed for email: {} with unexpected error: {}", user.getEmail(), e.getMessage(), e); // <--- Add logging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed: " + e.getMessage());
        }
    }
}