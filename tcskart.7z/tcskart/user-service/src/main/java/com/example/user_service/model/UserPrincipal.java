// com.example.user_service.model.UserPrincipal.java
package com.example.user_service.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections; // For creating an immutable singleton collection

// UserPrincipal acts as an adapter between your domain User and Spring Security's UserDetails
public class UserPrincipal implements UserDetails {

    private final User user; // Reference to your domain User object

    public UserPrincipal(User user) {
        this.user = user;
    }

    // Provides the user's roles/authorities to Spring Security.
    // It converts the UserRole enum to a SimpleGrantedAuthority,
    // prepending "ROLE_" as per Spring Security's convention for hasRole().
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singleton(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));
    }

    // Returns the user's hashed password
    @Override
    public String getPassword() {
        return user.getPassword();
    }

    // Returns the user's email, which acts as the username for authentication
    @Override
    public String getUsername() {
        return user.getEmail();
    }

    // These methods determine account status. Defaulting to true for simplicity.
    // In a real app, you might add corresponding fields to your User entity
    // and return their values (e.g., isAccountNonExpired, isAccountNonLocked, isCredentialsNonExpired, isEnabled).
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    // Optional: Provide a getter to access the underlying User object if needed
    // This allows you to retrieve user-specific data (like ID, name, address)
    // from the SecurityContext after authentication.
    public User getUser() {
        return user;
    }
}