package com.example.user_service.errorhandling;

public class UserAlreadyExistsException extends RuntimeException {

    // Constructor that accepts a custom error message
    public UserAlreadyExistsException(String message) {
        super(message);
    }

    // Constructor that accepts a custom message and a cause (another Throwable)
    public UserAlreadyExistsException(String message, Throwable cause) {
        super(message, cause);
    }
}
