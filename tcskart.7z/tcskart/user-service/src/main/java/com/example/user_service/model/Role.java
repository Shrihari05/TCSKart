package com.example.user_service.model;

public enum Role {
 ADMIN, CUSTOMER
}
