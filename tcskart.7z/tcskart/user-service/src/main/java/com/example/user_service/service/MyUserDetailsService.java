// com.example.user_service.service.MyUserDetailsService.java
package com.example.user_service.service;

import com.example.user_service.dao.UserRepository;
import com.example.user_service.model.User;
import com.example.user_service.model.UserPrincipal; // Import your custom UserPrincipal
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

// Custom UserDetailsService to load user details for Spring Security
@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    // This method is called by Spring Security during the authentication process
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Fetch the User entity from the database using the email
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

        // Wrap your domain User object in UserPrincipal, which implements UserDetails
        return new UserPrincipal(user);
    }
}