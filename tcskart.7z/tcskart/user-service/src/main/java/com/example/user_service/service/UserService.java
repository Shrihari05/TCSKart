// com.example.user_service.service.UserService.java
package com.example.user_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.user_service.dao.UserRepository;
import com.example.user_service.errorhandling.UserAlreadyExistsException;
import com.example.user_service.model.LoginRequest;
import com.example.user_service.model.User;
import com.example.user_service.model.Role; // Import UserRole enum

@Service
public class UserService {

    private final UserRepository userRepository;
    private final AuthenticationManager authenticationManager;
    private final JWTService jwtService;
    // PasswordEncoder for hashing and verifying passwords
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12); // Strength 12

    @Autowired
    public UserService(UserRepository userRepository, AuthenticationManager authenticationManager, JWTService jwtService) {
        this.userRepository = userRepository;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    /**
     * Registers a new user.
     * @param user The User object containing registration details.
     * @return The saved User object.
     * @throws UserAlreadyExistsException if a user with the same email already exists.
     * @throws IllegalArgumentException if an invalid role is provided.
     */
    public User addUser(User user) {
        // Check if a user with this email already exists
        userRepository.findByEmail(user.getEmail())
                .ifPresent(existingUser -> {
                    throw new UserAlreadyExistsException("User with this email already exists: " + user.getEmail());
                });
        
        if(user.getRole() == null) {
        	 user.setRole(Role.CUSTOMER);
        }
       
       

        // Hash the plain-text password before saving
        user.setPassword(encoder.encode(user.getPassword()));
        userRepository.save(user); // Save the new user to the database
        return user;
    }

    /**
     * Authenticates the user and generates a JWT token upon successful authentication.
     * @param loginRequest Contains user's email and plain-text password.
     * @return A JWT token string if authentication is successful.
     * @throws BadCredentialsException if authentication fails (e.g., invalid email or password).
     */
    public String authenticateAndGetJwtToken(LoginRequest loginRequest) {
        Authentication authentication;
        try {
            // Attempt to authenticate the user using Spring Security's AuthenticationManager
            authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
        } catch (AuthenticationException e) {
            // Catch specific authentication failures and rethrow as BadCredentialsException
            throw new BadCredentialsException("Invalid email or password", e);
        }

        if (authentication.isAuthenticated()) {
            // If authentication succeeds, retrieve the User entity to get the ID and current role
            User user = userRepository.findByEmail(loginRequest.getEmail())
                                      .orElseThrow(() -> new IllegalStateException("User not found after successful authentication. This indicates a data inconsistency."));

            // Generate the JWT token including userId, email, and role
            return jwtService.generateToken(user.getId(), user.getEmail(), user.getRole().name());
        } else {
            // This case should ideally not be reached if authentication.isAuthenticated() is false and no exception was thrown
            throw new IllegalStateException("Authentication failed unexpectedly for user: " + loginRequest.getEmail());
        }
    }
}