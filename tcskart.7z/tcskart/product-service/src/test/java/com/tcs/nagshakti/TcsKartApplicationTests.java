package com.tcs.nagshakti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TcsKartApplicationTests {

	@Test
	void contextLoads() {
	}

}
