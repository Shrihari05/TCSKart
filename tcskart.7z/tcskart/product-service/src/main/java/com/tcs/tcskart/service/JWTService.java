package com.tcs.tcskart.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException; // Keep this import
import io.jsonwebtoken.SignatureAlgorithm; // Keep this import for generateToken if used
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey; // Use SecretKey for better type safety
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JWTService {

    // Inject the secret key from application.properties
    @Value("${jwt.secret.key}")
    private String SECRET_KEY;

    // --- Token Creation (Typically in Auth Service, but included for completeness if needed) ---
    // Note: This generateToken method is usually in the User Service.
    // If you are only using this service for validation in Product Service, this method can be removed.
    public String generateToken(String userName) {
        Map<String, Object> claims = new HashMap<>();
        // For a resource server, we primarily validate, not generate.
        // If you need to generate, ensure you add userId and role claims here too.
        return createToken(claims, userName);
    }

    private String createToken(Map<String, Object> claims, String userName) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(userName)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 30)) // 30 minutes expiration
                .signWith(getSignKey(), SignatureAlgorithm.HS256) // Use getSignKey() which returns SecretKey
                .compact();
    }

    // --- Token Validation and Extraction (Primary functions for Resource Server) ---

    // Extract username (subject) from token
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // Extract a specific claim from token
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // Extract all claims from token (CORRECTED SYNTAX FOR JJWT 0.11.0+)
    private Claims extractAllClaims(String token) {
        // Use Jwts.parser() and verifyWith() for modern JJWT versions
        return Jwts.parser()
                .verifyWith(getSignKey()) // Use verifyWith for SecretKey
                .build()
                .parseSignedClaims(token) // Use parseSignedClaims for signed JWTs
                .getPayload(); // Get the payload (Claims)
    }

    // Check if token is expired
    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    // Extract expiration date from token
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    // Validate token
    public Boolean validateToken(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }

    // Get the signing key from the base64 encoded secret
    // Changed return type to SecretKey for consistency with newer JJWT APIs
    private SecretKey getSignKey() {
        byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    // Added for better error logging in JwtFilter (as seen in your JwtFilter)
    public String extractUserEmailFromExpiredToken(String token) {
        try {
            return extractUsername(token);
        } catch (ExpiredJwtException e) {
            // Get subject from the claims of the expired token
            return e.getClaims().getSubject();
        } catch (Exception e) {
            return "unknown";
        }
    }
}