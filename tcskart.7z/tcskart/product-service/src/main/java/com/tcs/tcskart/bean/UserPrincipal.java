package com.tcs.tcskart.bean; // Package set to 'bean'

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

// UserPrincipal for Product Service: Adapts a minimal User (derived from JWT) to UserDetails
public class UserPrincipal implements UserDetails {

    private final User user; // This now correctly refers to com.tcs.tcskart.bean.User

    public UserPrincipal(User user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Crucial: Ensure the role from the JWT (e.g., "ADMIN") is prefixed with "ROLE_"
        // This will now correctly call getRole() on your custom User object.
        return Collections.singleton(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));
    }

    @Override
    public String getPassword() {
        // Password is not relevant for authentication in a resource server using JWT
        return null; // Or return an empty string ""
    }

    @Override
    public String getUsername() {
        // Username typically comes from the JWT's subject (email in our case)
        // This will now correctly call getEmail() on your custom User object.
        return user.getEmail();
    }

    // These methods determine account status. Defaulting to true as JWT implies valid user.
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public User getUser() {
        return user;
    }
}