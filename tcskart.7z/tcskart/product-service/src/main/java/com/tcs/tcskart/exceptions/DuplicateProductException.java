package com.tcs.tcskart.exceptions;

public class DuplicateProductException extends Exception {
public DuplicateProductException(String message) {
	super(message);
}
}
