package com.tcs.tcskart.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

@Configuration
@EnableWebSecurity(debug = true) // Keep debug logging enabled for now
@EnableMethodSecurity // Enable @PreAuthorize and @PostAuthorize
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter; // Our custom JWT filter

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(AbstractHttpConfigurer::disable) // Disable CSRF for stateless API
                .cors(cors -> cors.configurationSource(corsConfigurationSource())) // Configure CORS
                .authorizeHttpRequests(authorize -> authorize
                        // IMPORTANT: Permit OPTIONS requests for CORS preflight
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/products").hasRole("ADMIN")
                        // --- Product Service specific authorization rules (UPDATED PATHS) ---
                        // These paths now match your ProductController's @RequestMapping("/products")
                        // and individual method mappings.

                        // For @GetMapping("/get") which maps to /products/get
                        .requestMatchers("/products/").hasAnyRole("ADMIN", "CUSTOMER")

                        // For @PostMapping("/") which maps to /products
                        .requestMatchers(HttpMethod.POST, "/products/").hasRole("ADMIN")

                        // For @PutMapping("/{productId}") and @GetMapping("/{productId}") mapping to /products/{productId}
                        .requestMatchers("/products/{productId}").hasAnyRole("ADMIN", "CUSTOMER")

                        // For @DeleteMapping("/delete/{productId}") mapping to /products/delete/{productId}
                        .requestMatchers("/products/delete/{productId}").hasRole("ADMIN")

                        // For @PostMapping("/{productId}/{productsOrdered}") mapping to /products/{productId}/{productsOrdered}
                        .requestMatchers("/products/{productId}/{productsOrdered}").hasAnyRole("ADMIN", "CUSTOMER")

                        // For @GetMapping("/low-stock") mapping to /products/low-stock
                        .requestMatchers("/products/low-stock").hasRole("ADMIN")

                        // For @GetMapping("/searchProducts") mapping to /products/searchProducts
                        .requestMatchers("/products/searchProducts").hasAnyRole("ADMIN", "CUSTOMER")

                        // For @GetMapping("/search") mapping to /products/search
                        .requestMatchers("/products/search").hasAnyRole("ADMIN", "CUSTOMER")
                        .requestMatchers("/products/availability").hasAnyRole("CUSTOMER")
                        // All other requests must be authenticated (as a fallback)
                        .anyRequest().authenticated()
                )
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS) // Use stateless sessions for JWT
                )
                // Add our JWT filter before the Spring Security's default UsernamePasswordAuthenticationFilter
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    // CORS Configuration Bean
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // Allowed origins for your frontend application
        // Adjust these to match your actual frontend URL(s)
        configuration.setAllowedOrigins(Arrays.asList("http://localhost:5500", "http://127.0.0.1:5500"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*")); // Allow all headers (e.g., Authorization)
        configuration.setAllowCredentials(true); // Allow credentials (e.g., Authorization header)
        configuration.setMaxAge(3600L); // Cache preflight response for 1 hour

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        // Apply this CORS configuration to all paths within this microservice
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}