package com.tcs.tcskart.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tcs.tcskart.bean.Product;


@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	//lowstock
		List<Product> findByStockQuantityLessThan(int quantity);

	    // Search by name or category
	    @Query("SELECT p FROM Product p WHERE " +
	            "(LOWER(p.name) LIKE LOWER(CONCAT('%', :name, '%')) OR :name IS NULL) " +
	            "AND (LOWER(p.category) LIKE LOWER(CONCAT('%', :category, '%')) OR :category IS NULL)")
	    List<Product> findByNameAndCategory(String name, String category);
	    
	    List<Product> findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrCompanyContainingIgnoreCase(
	            String name, String description, String category,String company
	        );
	    
	    Optional<Product> findByNameIgnoreCaseAndCategoryIgnoreCase(String name, String category);
}
