package com.tcs.tcskart.exceptions;

public class LowStockException extends Exception {
public LowStockException(String message) {
	super(message);
}
}
