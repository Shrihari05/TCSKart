package com.tcs.tcskart.bean;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "product", uniqueConstraints = {
	    @UniqueConstraint(columnNames = {"name", "category"})
	})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;
    private String description;
    private double price;
    private String company;
    private String category;
    private int stockQuantity;
    private LocalDateTime createdAt;

    @OneToMany(cascade=CascadeType.ALL,orphanRemoval=true)
    @JoinColumn(name = "product_id") 
    private List<ProductImages> imgurl = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "product_id")
    private List<ProductAvailability> availability = new ArrayList<>();
}
