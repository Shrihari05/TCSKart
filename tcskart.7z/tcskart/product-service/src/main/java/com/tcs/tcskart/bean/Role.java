package com.tcs.tcskart.bean; // Package set to 'bean'

public enum Role {
    ADMIN, CUSTOMER
}