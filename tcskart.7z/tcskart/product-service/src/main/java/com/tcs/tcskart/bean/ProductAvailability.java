package com.tcs.tcskart.bean;

import jakarta.persistence.*;
import lombok.*;

@Entity

@Data @NoArgsConstructor @AllArgsConstructor
public class ProductAvailability {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    
    private String pincode;

    
    private int availableQuantity;

    @ManyToOne
    @JoinColumn(name = "product_id")  
    private Product product;
}
