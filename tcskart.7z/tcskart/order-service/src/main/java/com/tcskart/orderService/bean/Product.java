package com.tcskart.orderService.bean;

import java.time.LocalDateTime;
import java.util.List;

public record Product(
	long id,
    String name,
    String description,
    double price,
    String category,
    int stockQuantity,
    LocalDateTime createdAt,
    List<String> imageUrls){
}