package com.tcskart.orderService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class Exceptions {
	@ExceptionHandler(value=LowStockException.class)
	public ResponseEntity<?> lowStockException()
	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Your cart items have low stocks");
	}
}
