package com.tcskart.orderService.service;


import com.tcskart.orderService.bean.UserPrincipal; 
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

@Service
public class JwtBasedUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
       
        return new org.springframework.security.core.userdetails.User(
            username,
            "", 
            Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")) 
        );
    }
    public UserDetails buildUserDetailsFromClaims(String email, String role, Long userId) {
        return new UserPrincipal(userId, email, role);
    }
}