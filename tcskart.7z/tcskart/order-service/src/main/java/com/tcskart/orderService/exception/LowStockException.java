package com.tcskart.orderService.exception;

public class LowStockException extends RuntimeException{

}
