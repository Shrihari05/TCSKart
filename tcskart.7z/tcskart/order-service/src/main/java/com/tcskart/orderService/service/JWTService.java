package com.tcskart.orderService.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JWTService {

 @Value("${jwt.secret.key}")
 private String secretKey;

 public String generateToken(Long userId, String email, String role) {
     Map<String, Object> claims = new HashMap<>();
     claims.put("userId", userId); 
     claims.put("role", role);   

     return Jwts.builder()
             .setClaims(claims)         
             .setSubject(email)           
             .setIssuedAt(new Date())     
             .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) 
             .signWith(getKey())          
             .compact();                 
 }

 private SecretKey getKey() {
     if (secretKey == null || secretKey.isEmpty()) {
         throw new IllegalStateException("JWT Secret Key is not initialized. Please configure 'jwt.secret.key' in application.properties.");
     }
     byte[] keyBytes = Decoders.BASE64.decode(secretKey); 
     return Keys.hmacShaKeyFor(keyBytes); 
 }
 public String extractUserEmail(String token) {
     return extractClaim(token, Claims::getSubject);
 }

 public String extractRole(String token) {
     return extractClaim(token, claims -> claims.get("role", String.class));
 }
 public Long extractUserId(String token) {
     return extractClaim(token, claims -> claims.get("userId", Long.class));
 }
 private <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
     final Claims claims = extractAllClaims(token);
     return claimsResolver.apply(claims);         
 }
 private Claims extractAllClaims(String token) {
     return Jwts.parser()
             .verifyWith(getKey()) 
             .build()
             .parseSignedClaims(token) 
             .getPayload(); 
 }
 public boolean validateToken(String token, UserDetails userDetails) {
     final String userEmail = extractUserEmail(token);
     
     return (userEmail.equals(userDetails.getUsername()) && !isTokenExpired(token));
 }
 private boolean isTokenExpired(String token) {
     return extractExpiration(token).before(new Date());
 }
 private Date extractExpiration(String token) {
     return extractClaim(token, Claims::getExpiration);
 }
}