package com.tcskart.orderService.bean;

public enum  UserRole {
	 ADMIN,
	 CUSTOMER
}


