package com.tcs.tcskart.dto;

public record AvailabilityResponse(boolean available, int availableQuantity) {}
