package com.tcs.tcskart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.tcskart.bean.ProductAvailability;

public interface ProductAvailabilityRepository
extends JpaRepository<ProductAvailability, Long> {


ProductAvailability findByProductIdAndPincode(Long productId, String pincode);
}
