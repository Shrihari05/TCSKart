package com.tcs.tcskart.service;

import com.tcs.tcskart.bean.UserPrincipal;
import com.tcs.tcskart.bean.User;
import com.tcs.tcskart.bean.Role; // Ensure this import is correct

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class JwtBasedUserDetailsService {

    /**
     * Builds a Spring Security UserDetails object from JWT claims.
     * In a resource server, we don't query a database for user details;
     * all necessary user information for authorization comes directly from the validated JWT.
     *
     * @param email The subject (username) from the JWT.
     * @param role The role string from the JWT claims (e.g., "ADMIN", "CUSTOMER").
     * @param userId The userId from the JWT claims.
     * @return A UserDetails object encapsulating the user's identity and authorities.
     */
    public UserDetails buildUserDetailsFromClaims(String email, String role, Long userId) {
        // Create a simple User bean using information from the JWT
        User user = new User();
        user.setId(userId);
        user.setEmail(email);
        // Convert the role string from JWT to your Role enum
        user.setRole(Role.valueOf(role.toUpperCase()));

        // Wrap your custom User bean in UserPrincipal, which implements UserDetails
        return new UserPrincipal(user);
    }
}