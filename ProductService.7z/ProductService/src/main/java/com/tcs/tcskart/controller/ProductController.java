package com.tcs.tcskart.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.tcskart.bean.Product;
import com.tcs.tcskart.dto.AvailabilityResponse;
import com.tcs.tcskart.exceptions.DuplicateProductException;
import com.tcs.tcskart.exceptions.LowStockException;
import com.tcs.tcskart.service.ProductService;

import jakarta.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/products")
public class ProductController {

	private ProductService productService;

	public ProductController(ProductService productService) {
		this.productService = productService;
	}

	@PostMapping("/")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> addProduct(@RequestBody Product product) throws IOException, DuplicateProductException, LowStockException {

		Map<String, Object> response = new HashMap<>();

		Product savedProduct = productService.addProduct(product);

		if (savedProduct == null) {
			response.put("status", false);
			response.put("message", "Product is empty. error while adding...");
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

		response.put("status", "success");
		response.put("message", "Product Added successfully!");
		response.put("data", savedProduct); // Return savedProduct to include generated ID if any
		return new ResponseEntity<>(response, HttpStatus.CREATED); // Use HttpStatus.CREATED for resource creation
	}

	@GetMapping("/")
	@PreAuthorize("hasAnyRole('ADMIN','CUSTOMER')")
	public ResponseEntity<Map<String, Object>> getAllProducts() {

		List<Product> products = productService.getAllProducts();

		Map<String, Object> response = new HashMap<>();

		if (products == null || products.isEmpty()) { 
			response.put("success", false);
			response.put("message", "No products Found");
		} else {
			response.put("success", true);
			response.put("message", "Products retrieved successfully."); 
			response.put("data", products); 
		}

		return ResponseEntity.ok(response);
	}

	// Update Products-10
	@PutMapping("/{productId}")
	@PreAuthorize("hasAnyRole('ADMIN','CUSTOMER')") 
	public ResponseEntity<Map<String, Object>> updateProductById(@RequestBody Product product,
			@PathVariable long productId) throws IOException {

		Map<String, Object> response = new HashMap<>();

		try {
			Product updatedProduct = productService.updateProductById(product, productId);

			response.put("status", "success");
			response.put("message", "Product " + productId + " got updated successfully!");
			response.put("data", updatedProduct);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}catch (Exception e) {
			response.put("status", "error");
			response.put("message", "Error while updating product: " + e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR); 
		}
	}

	// Delete Product by ID-11
	@DeleteMapping("/delete/{productId}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> deleteProductById(@PathVariable long productId) {
		Map<String, Object> response = new HashMap<>();

		try {
			boolean deletedProduct = productService.deleteProductById(productId);

			if (deletedProduct) {
				response.put("success", true);
				response.put("message", "Product Deleted Successfully...");
				return ResponseEntity.ok(response);
			} else {
				
				response.put("success", false);
				response.put("message", "Product Deletion Failed...");
				return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			response.put("success", false);
			response.put("message", "Error while deleting product: " + e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Get Product By ID-7
	@GetMapping("/{productId}")
	@PreAuthorize("hasAnyRole('ADMIN','CUSTOMER')") 
	public ResponseEntity<Map<String, Object>> getProducById(@PathVariable Long productId) {

		Map<String, Object> response = new HashMap<>();

		try {
			Product product = productService.getProductById(productId);

			response.put("success", true);
			response.put("message", "Product found");
			response.put("data", product);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			response.put("success", false);
			response.put("message", "Error while retrieving product: " + e.getMessage());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// decrease product ordering
	
	@PostMapping("/{productId}/{productsOrdered}")
	@PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')") // Decide who can decrease stock (e.g., customer on order, admin for adjustments)
	public ResponseEntity<Map<String, Object>> decreaseProductStockQuantityOnOrdering(@PathVariable long productId, @PathVariable int productsOrdered) throws LowStockException {

		Map<String, Object> response = new HashMap<>();
		try {
			productService.decreaseProductStockQuantityOnOrdering(productId, productsOrdered);
	 		response.put("success", true);
	 		response.put("message", "Product stock decreased successfully for product ID: " + productId);
	 		return ResponseEntity.ok(response);
		} catch (IllegalArgumentException e) {
			response.put("success", false);
			response.put("message", e.getMessage()); 
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		} 
	}

	// Notify admin for low-stock-33
	@GetMapping("/low-stock")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Map<String, Object>> getLowStockProducts() {

		List<Product> products = productService.getLowStockProducts(); 

		Map<String, Object> response = new HashMap<>();

		if (products.isEmpty()) {
			response.put("success", false);
			response.put("message", "No Products are Found with low Stock");
		} else {
			response.put("success", true);
			response.put("message", "Products found with low stock");
			response.put("data", products);
		}
 
		return ResponseEntity.ok(response);
	}

	// Search-20,21,4
	@GetMapping("/searchProducts")
	@PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')") 
	public ResponseEntity<Map<String, Object>> searchProducts(@RequestParam(required = false) String name,
			@RequestParam(required = false) String category) {
		List<Product> product = productService.searchProducts(name, category);

		Map<String, Object> response = new HashMap<>();

		if (product.isEmpty()) {
			response.put("success", false);
			response.put("message", "No Products are Found");
		} else {
			response.put("success", true);
			response.put("message", "Products found for the given name and category.");
			response.put("data", product);
		}
		return ResponseEntity.ok(response);
	}

	// searchBykeyword - 4
	@GetMapping("/search")
	@PreAuthorize("hasAnyRole('ADMIN', 'CUSTOMER')") 
	public ResponseEntity<Map<String, Object>> searchProducts(@RequestParam("keyword") String keyword) {
		List<Product> product = productService.searchProducts(keyword);

		Map<String, Object> response = new HashMap<>();

		if (product.isEmpty()) {
			response.put("success", false);
			response.put("message", "No Products are Found");
		} else {
			response.put("success", true);
			response.put("message", "Products found for the given keyword");
			response.put("data", product);
		}
		return ResponseEntity.ok(response);
	}
	
	//Location
		@GetMapping("/{productId}/availability")
		@PreAuthorize("hasAnyRole('CUSTOMER')") 
	    public ResponseEntity<AvailabilityResponse> checkAvailability(
	            @PathVariable Long productId,
	            @RequestParam String pincode) {

	        AvailabilityResponse res = productService.checkAvailability(productId, pincode);
	        return ResponseEntity.ok(res);
	    }
		
		
		

}