package com.tcs.tcskart.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tcs.tcskart.bean.Product;
import com.tcs.tcskart.bean.ProductAvailability;
import com.tcs.tcskart.bean.ProductImages;
import com.tcs.tcskart.dto.AvailabilityResponse;
import com.tcs.tcskart.exceptions.DuplicateProductException;
import com.tcs.tcskart.exceptions.LowStockException;
import com.tcs.tcskart.repository.ProductAvailabilityRepository;
import com.tcs.tcskart.repository.ProductRepository;

import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletRequest;

@Service
public class ProductService {
	
	public static final int MINIMUM_PRODUCT_STOCK_QUANTITY = 5;

	private AdminNotificationService notifier;
	private ProductAvailabilityRepository productAvailabilityRepository;
	private ProductRepository productRepository;

	public ProductService(ProductRepository productRepository,AdminNotificationService notifier,ProductAvailabilityRepository productAvailabilityRepository) {
		this.productRepository = productRepository;
		this.productAvailabilityRepository=productAvailabilityRepository;
		this.notifier=notifier;
	}

	// Add Product
	public Product addProduct(Product product) throws IOException, DuplicateProductException, LowStockException {
		// unique products
		Optional<Product> existing = productRepository.findByNameIgnoreCaseAndCategoryIgnoreCase(product.getName(),
				product.getCategory());

		if (existing.isPresent()) {
			throw new DuplicateProductException("Product with same name and category already exists.");
		}
		if (product.getCreatedAt() == null) {
			product.setCreatedAt(LocalDateTime.now());
		}
		
		
		

		notifyAdminAboutLowStock(product);
		return productRepository.save(product);
	}

	// Get All Products
	public List<Product> getAllProducts() {

		List<Product> products = productRepository.findAll();

		return products;
	}

	// Update Product
	public Product updateProductById(Product newProductDetails, long productId) throws IOException {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new EntityNotFoundException("Product with ID " + productId + " not found"));

		product.setName(newProductDetails.getName());
		product.setDescription(newProductDetails.getDescription());
		product.setPrice(newProductDetails.getPrice());
		product.setCompany(newProductDetails.getCompany());
		product.setCategory(newProductDetails.getCategory());
		product.setStockQuantity(newProductDetails.getStockQuantity());
		/* ---------- images ---------- */
	    product.getImgurl().clear();
	    if (newProductDetails.getImgurl() != null) {
	        for (ProductImages img : newProductDetails.getImgurl()) {
	            product.getImgurl().add(img);               // Hibernate sees additions
	        }
	    }
	    /* ---------- availability ---------- */
	    product.getAvailability().clear();
	    if (newProductDetails.getAvailability() != null) {
	        for (ProductAvailability pa : newProductDetails.getAvailability()) {
                               // maintain the back‑ref
	            product.getAvailability().add(pa);
	        }
	    }
		

		if (product.getStockQuantity() < MINIMUM_PRODUCT_STOCK_QUANTITY) {
			notifier.notifyLowStock(product);
		}
		return productRepository.save(product);

	}

	// Delete Product
	public boolean deleteProductById(long id) {

		if (!productRepository.existsById(id)) {
			throw new EntityNotFoundException("Product with ID " + id + " not found");
		}

		productRepository.deleteById(id);

		if (!productRepository.existsById(id)) {
			return true;
		}

		return false;

	}

	// GetProductById
	public Product getProductById(long id) {

		return productRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Product with ID " + id + " not found"));

	}

	// decreaseProductQuantityOnOrder
	public void decreaseProductStockQuantityOnOrdering(long productId, int productsOrdered) throws LowStockException {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new EntityNotFoundException("Product with ID " + productId + " not found"));
		product.setStockQuantity(product.getStockQuantity() - productsOrdered);
		notifyAdminAboutLowStock(product);
		productRepository.save(product);

	}

	// notifyAdminAboutLowStock
	public void notifyAdminAboutLowStock(Product product) throws LowStockException {

		if (product.getStockQuantity() < MINIMUM_PRODUCT_STOCK_QUANTITY) {
			notifier.notifyLowStock(product);
			throw new LowStockException("Stock is below minimum threshold.");
		}
	}

	// searchProducts
	public List<Product> searchProducts(String name, String category) {
		return productRepository.findByNameAndCategory(name, category);
	}

	// lowStock Service
	public List<Product> getLowStockProducts() {
		return productRepository.findByStockQuantityLessThan(MINIMUM_PRODUCT_STOCK_QUANTITY);
	}

	// search by keyword
	public List<Product> searchProducts(String keyword) {
		return productRepository
				.findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrCompanyContainingIgnoreCase(
						keyword, keyword, keyword, keyword);
	}

	// location
	public AvailabilityResponse checkAvailability(Long productId, String pincode) {

		productRepository.findById(productId)
				.orElseThrow(() -> new EntityNotFoundException("Product " + productId + " not found"));

		ProductAvailability result = productAvailabilityRepository.findByProductIdAndPincode(productId, pincode);
		
		if (result != null && result.getAvailableQuantity() > 0) {
			return new AvailabilityResponse(true, result.getAvailableQuantity());
		}
		return new AvailabilityResponse(false, 0);
	}
	

}