package com.example.user_service.model;

import com.fasterxml.jackson.annotation.JsonProperty; // Import JsonProperty
import com.fasterxml.jackson.annotation.JsonProperty.Access; // Import Access enum

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // Generates getters, setters, toString, equals, hashCode
@NoArgsConstructor // Lombok annotation for no-arg constructor
@Entity
@Table(name="users") // Maps this entity to a database table named "users"
public class User {

    @Id // Marks this field as the primary key
    @GeneratedValue(strategy=GenerationType.IDENTITY) // Auto-generates ID using database identity column
    private Long id; // Unique identifier for the user

    private String name; // User's full name

    @Column(unique= true, nullable = false) // Ensures email is unique and not null in DB
    private String email; // User's email, used as username for login

    // --- CRUCIAL CHANGE HERE ---
    @JsonProperty(access = Access.WRITE_ONLY) // Allows 'password' to be read from incoming JSON, but not written to outgoing JSON
    @Column(nullable=false) // Ensures password is not null in DB
    private String password; // User's hashed password (will be received as plain text here, then hashed)
    // --- END CRUCIAL CHANGE ---

    @Enumerated(EnumType.STRING) // Stores the enum name (e.g., "CUSTOMER", "ADMIN") as a string in DB
    @Column(nullable = false) // Ensures role is not null in DB
    private Role role; // User's role (CUSTOMER or ADMIN)

    private String address; // User's address

    // Constructor with common fields (ID is auto-generated)
    public User(String name, String email, String password, Role role, String address) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.address = address;
    }
}